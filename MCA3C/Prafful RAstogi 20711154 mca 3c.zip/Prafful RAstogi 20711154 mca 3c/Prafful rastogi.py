from random import shuffle
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
df=pd.read_csv("pollution.csv")
print(df)
AQI_value=df["AQI"]
AQI_value.plot(kind='hist')
df.plot(x="year",y="AQI",kind="scatter")


train, test=train_test_split(df,test_size=0.2,random_state=33,shuffle=True)
print(test)
print(train)